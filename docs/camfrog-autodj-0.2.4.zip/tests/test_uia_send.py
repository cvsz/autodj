"""Regression test for the foreground-send clipboard/focus-stealing bug (see AUDIT.md F-send-overwrite):
_send_fg() used to paste straight into Camfrog's own chat box without clearing it first, so any unsent
text already sitting in that box (someone mid-typing, or something they'd pasted themselves) got the
bot's message appended to it, and Enter then submitted the whole mashed-together line under this account.
No real Windows/pywinauto needed: pyperclip, pywinauto.keyboard and winmsg are faked just enough to record
the exact sequence of key presses and clipboard writes _send_fg() performs."""
import sys
import types

import pytest


def _fake_env(monkeypatch, calls):
    pyperclip = types.ModuleType("pyperclip")
    pyperclip.paste = lambda: "previous-clipboard-contents"
    pyperclip.copy = lambda s: calls.append(("clip", s))
    monkeypatch.setitem(sys.modules, "pyperclip", pyperclip)

    pywinauto = types.ModuleType("pywinauto")
    keyboard = types.ModuleType("pywinauto.keyboard")
    keyboard.send_keys = lambda s: calls.append(("keys", s))
    pywinauto.keyboard = keyboard
    monkeypatch.setitem(sys.modules, "pywinauto", pywinauto)
    monkeypatch.setitem(sys.modules, "pywinauto.keyboard", keyboard)


class FakeWin:
    def __init__(self):
        self.handle = 111

    def is_minimized(self):
        return False

    def set_focus(self):
        pass


class FakeInput:
    def __init__(self):
        self.focused = False

    def click_input(self):
        self.focused = True

    def set_focus(self):
        self.focused = True


def _adapter(web: bool):
    import camfrog_autodj.adapters.uia as uia
    a = object.__new__(uia.UiaAdapter)  # bypass __init__: no real Windows/Desktop needed for this unit
    a.win = FakeWin()
    a._input = FakeInput()
    a._web = web
    return a


def test_send_fg_clears_the_box_before_pasting_web_mode(monkeypatch):
    calls = []
    _fake_env(monkeypatch, calls)
    monkeypatch.setattr("camfrog_autodj.winmsg.foreground", lambda: 0)
    monkeypatch.setattr("camfrog_autodj.winmsg.restore_foreground", lambda h: None)
    a = _adapter(web=True)
    a._send_fg("Now playing: Some Song")
    keys = [v for k, v in calls if k == "keys"]
    clips = [v for k, v in calls if k == "clip"]
    assert keys.index("^a") < keys.index("^v") < keys.index("{ENTER}"), keys  # select-all BEFORE paste BEFORE enter
    assert clips[0] == "Now playing: Some Song"             # our message is what actually gets pasted
    assert clips[-1] == "previous-clipboard-contents"        # the user's own clipboard is restored afterwards
    assert a._input.focused is True


def test_send_fg_clears_the_box_before_pasting_text_mode(monkeypatch):
    calls = []
    _fake_env(monkeypatch, calls)
    monkeypatch.setattr("camfrog_autodj.winmsg.foreground", lambda: 0)
    monkeypatch.setattr("camfrog_autodj.winmsg.restore_foreground", lambda h: None)
    a = _adapter(web=False)
    a._send_fg("skip")
    keys = [v for k, v in calls if k == "keys"]
    assert keys.index("^a") < keys.index("^v")
