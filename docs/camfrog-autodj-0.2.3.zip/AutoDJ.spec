# -*- mode: python ; coding: utf-8 -*-
# Equivalent of the options in build.ps1 (which regenerates this file: edit build.ps1, not this).
from PyInstaller.utils.hooks import collect_all, collect_submodules

hiddenimports = ['comtypes', 'pyperclip', 'mutagen']
hiddenimports += collect_submodules('camfrog_autodj')
hiddenimports += collect_submodules('pywinauto')
hiddenimports += collect_submodules('pyttsx3')
yt_datas, yt_binaries, yt_hidden = collect_all('yt_dlp')  # extractors are imported dynamically
hiddenimports += yt_hidden


a = Analysis(
    ['run_autodj.py'],
    pathex=[],
    binaries=yt_binaries,
    datas=[('app.ico', '.')] + yt_datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='AutoDJ',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    version='version_info.txt',
    icon=['app.ico'],
)
