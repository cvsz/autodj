from __future__ import annotations


def synth(text: str, path: str, cfg) -> None:
    import pyttsx3
    eng = pyttsx3.init()
    eng.setProperty("rate", cfg.tts_rate)
    if cfg.tts_voice:
        for v in eng.getProperty("voices"):
            if cfg.tts_voice.lower() in v.name.lower():
                eng.setProperty("voice", v.id)
                break
    eng.save_to_file(text, path)
    eng.runAndWait()
