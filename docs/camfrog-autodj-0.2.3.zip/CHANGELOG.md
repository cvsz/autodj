# Changelog

## 0.2.3
`make` on plain Windows PowerShell/cmd.

### Fixed
- `make help` (and every other target) failed on Windows with confusing cascading errors ("The system cannot find the path specified", then `awk` "CreateProcess ... failed") when `make` was installed but bash/awk/coreutils were not on PATH. `SHELL` no longer hard-codes the Linux path `/bin/bash` (now resolved via PATH, so it also works if Git Bash's `bash.exe` is on PATH without being at that exact path). More importantly, the Makefile now checks for `bash` up front and fails with ONE clear message explaining the two real options: run `make` from inside Git Bash, or skip `make` entirely and use `build.ps1` / `python -m pytest` directly (which is what `make` wraps anyway and needs no Unix tools at all).

## 0.2.2
"Grand" GUI pass: a living, decorated now-playing stage.

### Added
- The now-playing panel now has a drifting aurora backdrop (slow colour bands) with a twinkling starfield behind the record, and ~26 soft particles orbiting it that brighten and dim with the music.
- A burst of ~22 confetti pieces fires from the record whenever a new track starts (including the first).
- The whole window now has a thin border that glows pink in time with the music while a track plays, and fades out when paused/idle.
- The AUTODJ wordmark in the header has a soft duplicate-text glow behind it.
- `camfrog_autodj/visuals.py`: `aurora_offset`, `make_particles`/`particle_pos`, `confetti_burst`/`confetti_pos` (pure functions, unit-tested, no Tk needed to test them).

### Fixed
- An internal naming collision: the new window-border-glow state was stored under the same attribute (`self._glow`) already used for the vinyl's halo-ring canvas items, so turning on the border glow crashed the animation loop (`TypeError` mixing a float with a list) every frame while a track played. Caught by `tests/test_gui_logic.py` before release; renamed to `self._border_glow`.

## 0.2.1
Dev-convenience `Makefile` (cross-platform: Linux/macOS/WSL/Git-Bash with `make`; the Windows `.exe` is still built by `build.ps1`, which the Makefile just wraps).

### Added
- `Makefile` with targets for install, run (gui/console/headless), `check`/`discover`/`windows`/`say`, test (`test`, `test-v`, `test-one`, `coverage`), `lint`/`fmt`/`typecheck` (use `ruff`/`black`/`mypy` if installed, fall back gracefully otherwise), `build`/`build-clean`/`sign` (wrap `build.ps1`/`tools/sign_exe.ps1` on Windows; a clear message elsewhere), a one-shot `release` target (changelog check -> test -> build+sign -> package), `package` (zip the source tree), and housekeeping (`clean`/`clean-all`/`distclean`). `make help` lists everything.
- `make build`/`build-clean`/`sign`/`release` take `PFX=`, `PASSWORD=`, `THUMBPRINT=`, `SUBJECT=`, `NOSIGN=1` and pass them straight through to `build.ps1`'s own signing options (same env vars also still work). With none of these, `build.ps1` already signs automatically (self-signed certificate, created/trusted once) -- the Makefile does not change that default, it just exposes the same choices `build.ps1` always had.
- `tools/minipytest.py` and `tools/mutate.sh` are now part of the shipped project (previously only used ad hoc), so `make test` and `make mutation-smoke` work out of the box even before `pip install -e .[dev]`.
- `tools/package.py`: the zip-building logic `make package` uses.

### Fixed
- `tools/minipytest.py` resolved the project root incorrectly when given a single test file (`make test-one T=tests/x.py`): `camfrog_autodj` was not importable. Also did not understand pytest's `file.py::test_name` node-id syntax (silently ran zero tests). Both fixed.
- The Makefile's original `package` target built the zip with a multi-line heredoc inside a recipe; `make` runs each recipe line in its own shell by default, so the heredoc never worked (`make package` failed every time). Moved into `tools/package.py`.
- `make coverage` printed a raw `No module named coverage` twice instead of a clear message when the optional `coverage` package is not installed.

## 0.2.0
Audit release (details and evidence in `AUDIT.md`) plus a new GUI.

### Fixed
- **Bot reacted to its own chat lines.** The `!help` reply began with `!play ...`; when `bot_nick` did not match the account's real nick it was executed as a play request. Help now starts with a label, wrapped continuation lines can no longer start with the command prefix, and lines the bot posted are recognised when they come back from the room.
- **A failing track could flood the room.** With mpv missing or yt-dlp unavailable and a non-empty autoplay pool the player retried in a tight loop (measured: ~9,900 attempts and ~29,700 queued chat messages in half a second). Failures now back off (1, 2, 4 ... 30 s), are announced at most 3 times in a row, and the reason from mpv's own log is written to the log.
- **`No module named 'yt_dlp'` in AutoDJ.exe.** Lookups use `yt-dlp.exe` (next to mpv, on PATH, or `ytdlp_path`) when present and fall back to the module; if neither exists the room gets a short message and the log says exactly what to do. `build.ps1` now refuses to build when a required package is missing, bundles yt-dlp with `--collect-all`, builds without UPX, and smoke-tests the exe.
- **`config.toml` errors crashed with a traceback.** Now: the offending line with a `^`, a hint, exit code 2. Unknown settings get "did you mean", wrong types/values (`admins = "nick"` used to become the admin set `{n,i,c,k}`), bad regexes and out-of-range numbers are reported by name.
- `!remove` could remove a different request if the queue shifted (and so could the GUI's Remove button): removal is now by identity.
- A user could exceed `max_requests_per_user` by firing requests while earlier lookups were still running: limits are re-checked atomically after the lookup.
- Auto-discovery could write an unreadable config (and wrote it non-atomically): values are escaped, the result is validated before saving, the write is atomic.
- `pause`/`resume` no longer claim success when mpv's control pipe was not ready.
- GUI: one exception in the polling loop froze the window forever; the chat box grew without limit.
- Control characters in text sent to the room (typed as keystrokes) are stripped. Reloading a folder no longer duplicates the autoplay pool. The send throttle wakes up at shutdown. More worker threads, so a slow lookup does not block `!skip`.

### Added
- `--check` (diagnose mpv, yt-dlp, JS runtime hint, folders, admins, optional packages, Camfrog window), `--version`, `--log-file` / `log_file`.
- `!history` (`!ประวัติ`), `!block` / `!unblock` and `blocked_users`, refusal of songs already queued or playing, `ytdlp_path`, `poll_interval`.
- GUI redesign: neon dark theme, spinning record, animated equaliser, gradient progress, custom volume slider, ON AIR light, Queue / History / Chat tabs, shuffle/repeat chips, keyboard shortcuts, mpv-missing banner, HiDPI + dark title bar on Windows.
- Tests: 78 (was 32), including regression tests for each fix, a strict fake Tk for the GUI logic, and a pre-flight for the build environment. CI workflow, `.gitignore`, pytest settings.

### Changed
- Test fixture `make()` now returns a distinct source per request (the duplicate guard needs it).
